import { Component } from '@angular/core';

@Component({
  selector: 'hospital-page-500',
  standalone: true,
  imports: [],
  templateUrl: './page-500.component.html',
  styleUrl: './page-500.component.scss'
})
export class Page500Component {

}
